var structdrv__ext__light__rgb__sequence__t =
[
    [ "color", "structdrv__ext__light__rgb__sequence__t.html#a2da4bc8b6b4448f3e2608be112a51495", null ],
    [ "sequence_vals", "structdrv__ext__light__rgb__sequence__t.html#a1ff89d7d160e9019b4cf4f442f402d5d", null ]
];