var structdrv__ext__light__data__t =
[
    [ "p_status", "structdrv__ext__light__data__t.html#aa223e30cb00d450f95cf56af21801cf7", null ],
    [ "timer", "structdrv__ext__light__data__t.html#ab55f41c2b0a716fd0debe1d6393cbcd2", null ]
];