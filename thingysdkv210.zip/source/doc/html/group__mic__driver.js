var group__mic__driver =
[
    [ "m_audio_frame_t", "structm__audio__frame__t.html", null ],
    [ "drv_mic_data_handler_t", "group__mic__driver.html#ga8118c891881fd85361206babdd62ee9e", null ],
    [ "drv_mic_init", "group__mic__driver.html#gae30bb9aae26f934ce3f3bba2d3b14e30", null ],
    [ "drv_mic_start", "group__mic__driver.html#ga7a01bfd9dbaab58917adec341252a10f", null ],
    [ "drv_mic_stop", "group__mic__driver.html#ga441495fe612e58c1eda7c0c7fd411c00", null ]
];