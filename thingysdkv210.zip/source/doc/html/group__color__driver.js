var group__color__driver =
[
    [ "BH1745 color sensor", "group__bh1745__color.html", "group__bh1745__color" ],
    [ "drv_color_init_t", "structdrv__color__init__t.html", null ],
    [ "drv_color_data_handler_t", "group__color__driver.html#ga42589e7daa4a1450e076a490818f7580", null ],
    [ "drv_color_data_t", "group__color__driver.html#ga45d7c075869ef58e4d33998e199761b8", null ],
    [ "drv_color_init", "group__color__driver.html#gafc1593b85824d659f299d92a38af3457", null ],
    [ "drv_color_sample", "group__color__driver.html#ga9d66bf8535ab5353fd6d112ddc4f12ea", null ],
    [ "drv_color_start", "group__color__driver.html#ga0c0efca6c1046faff4b02acf493882b9", null ],
    [ "drv_color_stop", "group__color__driver.html#gac0dc86f10799a2572b812ed6510d03ae", null ]
];