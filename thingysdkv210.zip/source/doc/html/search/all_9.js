var searchData=
[
  ['led_5fchar_5fhandles',['led_char_handles',['../structble__uis__s.html#ac1b173438ef00fb8687d979309d917d4',1,'ble_uis_s']]],
  ['led_5fwrite_5fhandler',['led_write_handler',['../structble__uis__init__t.html#af080cc44ee6ce05b2e005426109817e4',1,'ble_uis_init_t::led_write_handler()'],['../structble__uis__s.html#a2198cbc105e8c8f6b4ebb4cfc285b0b5',1,'ble_uis_s::led_write_handler()']]],
  ['level_5fpercent',['level_percent',['../structm__batt__meas__event__t.html#ab5428192b1c275fe39849bd5296bcf38',1,'m_batt_meas_event_t']]],
  ['lis3dh_20accelerometer',['LIS3DH accelerometer',['../group__lis3dh__acc.html',1,'']]],
  ['low_5fpower',['LOW_POWER',['../group__lis3dh__acc.html#gga12c0d2c58f6ec2f4f2b2af14681e532fa04ef9c54bf8fecf6499edcc41b7281d7',1,'drv_acc_lis3dh_types.h']]],
  ['lpfp_5fres_5freg',['LPFP_RES_REG',['../group__lps22hb__press__driver.html#gaeb18c510346de8929ea535be6a0bafb5',1,'drv_lps22hb.h']]],
  ['lps22hb_20pressure_20sensor',['LPS22HB pressure sensor',['../group__lps22hb__press__driver.html',1,'']]]
];
