var searchData=
[
  ['over_2dthe_2dair_20device_20firmware_20update_20_28ota_2ddfu_29',['Over-the-air device firmware update (OTA-DFU)',['../dfu.html',1,'']]],
  ['ota_2ddfu_20with_20nrf_20connect',['OTA-DFU with nRF Connect',['../dfu_connect.html',1,'dfu']]],
  ['ota_2ddfu_20_2d_20generating_20your_20own_20packages',['OTA-DFU - Generating your own packages',['../dfu_generating.html',1,'dfu']]],
  ['odr_5f100hz',['ODR_100Hz',['../group__lis3dh__acc.html#gga0e9afd8ad27de0920d1fe0738834869ca52b611011f7bd3c0c447fc69c124d431',1,'drv_acc_lis3dh_types.h']]],
  ['odr_5f10hz',['ODR_10Hz',['../group__lis3dh__acc.html#gga0e9afd8ad27de0920d1fe0738834869ca3c93731a8c7fd26b42d3c1c7e0e04a16',1,'drv_acc_lis3dh_types.h']]],
  ['odr_5f1344hz_5fnp_5f5367hz_5flp',['ODR_1344Hz_NP_5367HZ_LP',['../group__lis3dh__acc.html#gga0e9afd8ad27de0920d1fe0738834869ca2ed2f9480618e711bbaa902ab5ac8da5',1,'drv_acc_lis3dh_types.h']]],
  ['odr_5f1620hz_5flp',['ODR_1620Hz_LP',['../group__lis3dh__acc.html#gga0e9afd8ad27de0920d1fe0738834869cafd7430b471127a6b595bcbf166bf8618',1,'drv_acc_lis3dh_types.h']]],
  ['odr_5f1hz',['ODR_1Hz',['../group__lis3dh__acc.html#gga0e9afd8ad27de0920d1fe0738834869ca651251b680468ae6418ce5e4881dd77f',1,'drv_acc_lis3dh_types.h']]],
  ['odr_5f200hz',['ODR_200Hz',['../group__lis3dh__acc.html#gga0e9afd8ad27de0920d1fe0738834869ca9f6133db3f2734f33ae2ca76ab4ef2ad',1,'drv_acc_lis3dh_types.h']]],
  ['odr_5f25hz',['ODR_25Hz',['../group__lis3dh__acc.html#gga0e9afd8ad27de0920d1fe0738834869ca89fb9bb7746edff5df4e510e45a901c7',1,'drv_acc_lis3dh_types.h']]],
  ['odr_5f400hz',['ODR_400Hz',['../group__lis3dh__acc.html#gga0e9afd8ad27de0920d1fe0738834869cac7b7c0d5277d1af336dfc9cc8209b45f',1,'drv_acc_lis3dh_types.h']]],
  ['odr_5f50hz',['ODR_50Hz',['../group__lis3dh__acc.html#gga0e9afd8ad27de0920d1fe0738834869ca96068b1baf9cd8b2e3e4fcff8e79ba65',1,'drv_acc_lis3dh_types.h']]],
  ['odr_5ft',['ODR_t',['../group__lis3dh__acc.html#ga0e9afd8ad27de0920d1fe0738834869c',1,'drv_acc_lis3dh_types.h']]],
  ['orientation_5fhandles',['orientation_handles',['../structble__tms__s.html#a8247e36053b95838ec8a84d641254fea',1,'ble_tms_s']]]
];
