var searchData=
[
  ['who_5fam_5fi_5freg',['WHO_AM_I_REG',['../group__hts221__humidity__driver.html#ga7e23ffa5bb718d06bcee89bbdf844ed8',1,'WHO_AM_I_REG():&#160;drv_hts221.h'],['../group__lps22hb__press__driver.html#ga7e23ffa5bb718d06bcee89bbdf844ed8',1,'WHO_AM_I_REG():&#160;drv_lps22hb.h']]]
];
