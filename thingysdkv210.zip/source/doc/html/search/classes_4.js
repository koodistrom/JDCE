var searchData=
[
  ['state_5fof_5fcharge_5ft',['state_of_charge_t',['../structstate__of__charge__t.html',1,'']]],
  ['sx150x_5fled_5fdrv_5fregs_5fvals_5ft',['sx150x_led_drv_regs_vals_t',['../structsx150x__led__drv__regs__vals__t.html',1,'']]]
];
