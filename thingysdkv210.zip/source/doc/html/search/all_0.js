var searchData=
[
  ['accaxesraw_5ft',['AccAxesRaw_t',['../struct_acc_axes_raw__t.html',1,'']]],
  ['active_5ftime_5fms',['active_time_ms',['../structdrv__ext__light__status__t.html#a9cc5cb3a61f1ed082266362135887d07',1,'drv_ext_light_status_t']]],
  ['adc_5fpin_5fno',['adc_pin_no',['../structbatt__meas__param__t.html#a0fa6444796cc22152ae2357a9de7ae63',1,'batt_meas_param_t']]],
  ['adc_5fpin_5fno_5fain',['adc_pin_no_ain',['../structbatt__meas__param__t.html#a235e3292de0a02e964849b06b8a7d704',1,'batt_meas_param_t']]],
  ['adv_5fparam_5fhandles',['adv_param_handles',['../structble__tcs__s.html#a3bc36c7a22700bb4e64b5ab49bea4a5c',1,'ble_tcs_s']]],
  ['app_5fbeacon_5finit',['app_beacon_init',['../group__ble__sdk__adv__beacon.html#ga910fb7695461046e9960641ef24f3bd5',1,'advertiser_beacon.h']]],
  ['app_5fbeacon_5fon_5fsys_5fevt',['app_beacon_on_sys_evt',['../group__ble__sdk__adv__beacon.html#ga5b124312305b07abeba16935fd12f220',1,'advertiser_beacon.h']]],
  ['app_5fbeacon_5fstart',['app_beacon_start',['../group__ble__sdk__adv__beacon.html#ga19c62b53343df829bf17cacc9a00e87f',1,'advertiser_beacon.h']]],
  ['app_5fbeacon_5fstop',['app_beacon_stop',['../group__ble__sdk__adv__beacon.html#ga750bb9f257312ff2f4187ec158178fe8',1,'advertiser_beacon.h']]],
  ['app_5ftimer_5fprescaler',['app_timer_prescaler',['../structbatt__meas__param__t.html#a9ca8fd3a0a0041f1d51e0824463f6c43',1,'batt_meas_param_t']]],
  ['av_5fconf_5freg',['AV_CONF_REG',['../group__hts221__humidity__driver.html#ga435c4cef8f7aedadecf8f8ed93cae28a',1,'drv_hts221.h']]],
  ['av_5fconf_5freg_5favgh_5fpos',['AV_CONF_REG_AVGH_Pos',['../group__hts221__humidity__driver.html#ga231dcf078125964af699b9570125fbab',1,'drv_hts221.h']]],
  ['av_5fconf_5freg_5favgt_5fpos',['AV_CONF_REG_AVGT_Pos',['../group__hts221__humidity__driver.html#ga31c98f3b85eb9f0f72de2b0c84033290',1,'drv_hts221.h']]],
  ['axisenable_5ft',['AXISenable_t',['../group__lis3dh__acc.html#gad2021482d4a30768e22af92782a56a3c',1,'drv_acc_lis3dh_types.h']]],
  ['accelerometer',['Accelerometer',['../group__driver__acc.html',1,'']]]
];
