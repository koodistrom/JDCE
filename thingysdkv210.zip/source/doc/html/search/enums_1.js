var searchData=
[
  ['ble_5fuis_5fled_5fmode_5ft',['ble_uis_led_mode_t',['../group__ble__sdk__srv__uis.html#ga29a8fc60a3fb3bb9186a552a1f70e8d0',1,'ble_uis.h']]]
];
