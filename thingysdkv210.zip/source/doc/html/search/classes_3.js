var searchData=
[
  ['m_5faudio_5fframe_5ft',['m_audio_frame_t',['../structm__audio__frame__t.html',1,'']]],
  ['m_5fbatt_5fmeas_5fevent_5ft',['m_batt_meas_event_t',['../structm__batt__meas__event__t.html',1,'']]],
  ['m_5fble_5fevt_5ft',['m_ble_evt_t',['../structm__ble__evt__t.html',1,'']]],
  ['m_5fble_5finit_5ft',['m_ble_init_t',['../structm__ble__init__t.html',1,'']]],
  ['m_5fble_5fservice_5fhandle_5ft',['m_ble_service_handle_t',['../structm__ble__service__handle__t.html',1,'']]],
  ['m_5fenvironment_5finit_5ft',['m_environment_init_t',['../structm__environment__init__t.html',1,'']]],
  ['m_5fmotion_5finit_5ft',['m_motion_init_t',['../structm__motion__init__t.html',1,'']]],
  ['m_5fui_5finit_5ft',['m_ui_init_t',['../structm__ui__init__t.html',1,'']]]
];
