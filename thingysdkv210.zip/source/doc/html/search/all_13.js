var searchData=
[
  ['valid_5fvoltage',['valid_voltage',['../structm__batt__meas__event__t.html#af3bba3b6ab6d11e014929bd6726e21ad',1,'m_batt_meas_event_t']]],
  ['voltage_5fdivider',['voltage_divider',['../structbatt__meas__param__t.html#a0a683f9a8f5bd335a207c556002b8e29',1,'batt_meas_param_t']]],
  ['voltage_5fdivider_5ft',['voltage_divider_t',['../structvoltage__divider__t.html',1,'']]],
  ['voltage_5fmv',['voltage_mv',['../structm__batt__meas__event__t.html#a68a8c5c913af88ed9100abd8e391ae25',1,'m_batt_meas_event_t']]],
  ['voltage_5fto_5fsoc',['voltage_to_soc',['../structstate__of__charge__t.html#abfc39dcdd555c9753128ba539437797c',1,'state_of_charge_t']]]
];
