var group__util =
[
    [ "Common macros", "group__macros__common.html", "group__macros__common" ],
    [ "Eddystone beacon", "group__ble__sdk__adv__beacon.html", "group__ble__sdk__adv__beacon" ],
    [ "Settings for Sx150x LED driver registers", "group__sx150x__led__drv__regs.html", "group__sx150x__led__drv__regs" ],
    [ "Support functions", "group__support__func.html", "group__support__func" ],
    [ "Sx150x LED driver register calculation", "group__sx150x__led__drv__calc.html", "group__sx150x__led__drv__calc" ]
];