var ble__tes_8h =
[
    [ "BLE_TES_MAX_DATA_LEN", "group__ble__sdk__srv__tes.html#gaf1cb0478a9d60bf219de42112859ec38", null ],
    [ "BLE_UUID_TES_SERVICE", "group__ble__sdk__srv__tes.html#ga74382e889100cb1e74c3681bd010724c", null ],
    [ "ble_tes_evt_handler_t", "group__ble__sdk__srv__tes.html#ga42620ff30ed437965e30197414292f23", null ],
    [ "ble_tes_color_set", "group__ble__sdk__srv__tes.html#ga96aa8f21018b192f8bb854859530bafe", null ],
    [ "ble_tes_gas_set", "group__ble__sdk__srv__tes.html#ga3d1629990a842eca0c6c96872eca7231", null ],
    [ "ble_tes_humidity_set", "group__ble__sdk__srv__tes.html#ga214c30d7b0f07f264ef3e2ceb0b10f47", null ],
    [ "ble_tes_init", "group__ble__sdk__srv__tes.html#ga6091b836154596e1478a21404f13ff2c", null ],
    [ "ble_tes_on_ble_evt", "group__ble__sdk__srv__tes.html#ga144e7065b310a35fcab8c3f2d94375d2", null ],
    [ "ble_tes_pressure_set", "group__ble__sdk__srv__tes.html#ga38d41753614fed2e730169d00d6edbb3", null ],
    [ "ble_tes_temperature_set", "group__ble__sdk__srv__tes.html#ga80bf34aaf088ad2437ba5b1fbea368b9", null ]
];