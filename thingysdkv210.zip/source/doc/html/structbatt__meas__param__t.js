var structbatt__meas__param__t =
[
    [ "adc_pin_no", "structbatt__meas__param__t.html#a0fa6444796cc22152ae2357a9de7ae63", null ],
    [ "adc_pin_no_ain", "structbatt__meas__param__t.html#a235e3292de0a02e964849b06b8a7d704", null ],
    [ "app_timer_prescaler", "structbatt__meas__param__t.html#a9ca8fd3a0a0041f1d51e0824463f6c43", null ],
    [ "batt_chg_stat_pin_no", "structbatt__meas__param__t.html#aeb8fcc57a40fd7458aa6d31549577d82", null ],
    [ "batt_mon_en_pin_no", "structbatt__meas__param__t.html#a310d12d80f4448fca30df7e26e1224a5", null ],
    [ "batt_mon_en_pin_used", "structbatt__meas__param__t.html#a8fd3192d7233181b20d89f9e277a7967", null ],
    [ "batt_voltage_limit_full", "structbatt__meas__param__t.html#a87835cef0315ba5c39c0e63ad552c5f7", null ],
    [ "batt_voltage_limit_low", "structbatt__meas__param__t.html#af15ce3f05c8b27c32ac601445a33e110", null ],
    [ "state_of_charge", "structbatt__meas__param__t.html#a14f6f056ef9542eb14fe43800f0cd78a", null ],
    [ "usb_detect_pin_no", "structbatt__meas__param__t.html#af749236629b2501099b6261ebe398583", null ],
    [ "voltage_divider", "structbatt__meas__param__t.html#a0a683f9a8f5bd335a207c556002b8e29", null ]
];