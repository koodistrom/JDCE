var group__m__motion__flash__config =
[
    [ "m_motion_flash_config_load", "group__m__motion__flash__config.html#ga3348dd7e7993ee4c2664651daaaca5c4", null ],
    [ "m_motion_flash_config_store", "group__m__motion__flash__config.html#ga4dfd4c5a6697b8bc9e8f294e8cd18757", null ],
    [ "m_motion_flash_init", "group__m__motion__flash__config.html#ga3467867a76dea6e5eb1f2a2c20220d74", null ]
];