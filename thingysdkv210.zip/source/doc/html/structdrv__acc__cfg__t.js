var structdrv__acc__cfg__t =
[
    [ "cpu_wake_pin", "structdrv__acc__cfg__t.html#a2c1936d9a000add1c5d56b45e30f3a7b", null ],
    [ "p_twi_cfg", "structdrv__acc__cfg__t.html#a2f89e21f0dd63d20b498109353c997ff", null ],
    [ "p_twi_instance", "structdrv__acc__cfg__t.html#a98044d67ca6038f7bd9d996e7c3c5f85", null ],
    [ "twi_addr", "structdrv__acc__cfg__t.html#a72ca241005adeeb56503b384d695a5a8", null ]
];