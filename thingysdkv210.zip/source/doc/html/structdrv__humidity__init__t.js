var structdrv__humidity__init__t =
[
    [ "p_twi_cfg", "structdrv__humidity__init__t.html#a685867e49b8615af10c50b56b9a6c11b", null ],
    [ "p_twi_instance", "structdrv__humidity__init__t.html#ae7505c24fb6c32e0a8a5fba968c3e831", null ]
];