var structdrv__ext__light__conf__t =
[
    [ "b", "structdrv__ext__light__conf__t.html#ab4318f02bebda5f69666bed4273cd57e", null ],
    [ "g", "structdrv__ext__light__conf__t.html#a2b68ad38e7f8e78b5d1928e1b5ec8400", null ],
    [ "mono", "structdrv__ext__light__conf__t.html#a1279ba65efa7d8035332b9b8c4bf5f73", null ],
    [ "p_data", "structdrv__ext__light__conf__t.html#aa751e4158d1010e16cf3dc2c5ac3b5a7", null ],
    [ "r", "structdrv__ext__light__conf__t.html#a428eead9f2186ce211fd2c70a4aab011", null ],
    [ "type", "structdrv__ext__light__conf__t.html#a4fe3df2a683d4951eee750c0a4f5aa73", null ]
];