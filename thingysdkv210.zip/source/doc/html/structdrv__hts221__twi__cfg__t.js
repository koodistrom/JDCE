var structdrv__hts221__twi__cfg__t =
[
    [ "p_twi_config", "structdrv__hts221__twi__cfg__t.html#a6c34d8d908539157fb1bf9c8a9c7da70", null ],
    [ "p_twi_instance", "structdrv__hts221__twi__cfg__t.html#aad2f34fbc23f1707a2a924ad692052eb", null ],
    [ "pin_int", "structdrv__hts221__twi__cfg__t.html#aa51fd479e3282606a7ece1008de43ea0", null ],
    [ "twi_addr", "structdrv__hts221__twi__cfg__t.html#a8c7253a73c43f1c2208390e53694d672", null ]
];