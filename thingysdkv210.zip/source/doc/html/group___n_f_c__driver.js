var group___n_f_c__driver =
[
    [ "drv_nfc_app_launch_android_record_add", "group___n_f_c__driver.html#ga95d7638c06217581c1ad00fac034f1da", null ],
    [ "drv_nfc_disable", "group___n_f_c__driver.html#ga0c4f91a3b027a1f1fce5a73e18e86d5a", null ],
    [ "drv_nfc_enable", "group___n_f_c__driver.html#gac789f1e7c8426c89cfc93dc37fde3af2", null ],
    [ "drv_nfc_init", "group___n_f_c__driver.html#ga736684fc0c3be4b91771fd06c4ec75d2", null ],
    [ "drv_nfc_string_record_add", "group___n_f_c__driver.html#gaa78b2dce3769711e3a3fa6867c9e9b60", null ],
    [ "drv_nfc_uri_record_add", "group___n_f_c__driver.html#gaf0d9d017a6abc18cf83fc517e41f4caa", null ]
];