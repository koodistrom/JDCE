var group__sx150x__led__drv__calc =
[
    [ "sx150x_led_drv_calc_convert", "group__sx150x__led__drv__calc.html#gaa2de58083f0d376cd8c62f89afe69614", null ],
    [ "sx150x_led_drv_calc_fade_supp", "group__sx150x__led__drv__calc.html#ga7e3001ab55720cc4c588cc2e23a9e5f9", null ],
    [ "sx150x_led_drv_calc_init", "group__sx150x__led__drv__calc.html#ga9907d106ed36ac6bb7a5e01abfd7b225", null ]
];