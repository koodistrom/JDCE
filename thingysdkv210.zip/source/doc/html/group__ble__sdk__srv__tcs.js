var group__ble__sdk__srv__tcs =
[
    [ "ble_tcs_init_t", "structble__tcs__init__t.html", [
      [ "evt_handler", "structble__tcs__init__t.html#aeb5b4651632901e483552e97436efa6e", null ]
    ] ],
    [ "ble_tcs_s", "structble__tcs__s.html", [
      [ "adv_param_handles", "structble__tcs__s.html#a3bc36c7a22700bb4e64b5ab49bea4a5c", null ],
      [ "conn_handle", "structble__tcs__s.html#aa0614613b1c7bc22a4e8c8f2eb92f9fa", null ],
      [ "conn_param_handles", "structble__tcs__s.html#a4ef5b98d85969326176dbe37ac1f5536", null ],
      [ "dev_name_handles", "structble__tcs__s.html#a3a063a210dd344b831584717989c8549", null ],
      [ "evt_handler", "structble__tcs__s.html#a4e21cc8c375065ede798c94934fa9aa3", null ],
      [ "service_handle", "structble__tcs__s.html#a7cdf0bc64e301eb2cbc8cd23f9239d54", null ],
      [ "uuid_type", "structble__tcs__s.html#a16efefe964dc754bb9aba36bb3656580", null ]
    ] ],
    [ "BLE_TCS_MAX_DATA_LEN", "group__ble__sdk__srv__tcs.html#ga8146f33ea6bcd138284006cf86405694", null ],
    [ "BLE_UUID_TCS_SERVICE", "group__ble__sdk__srv__tcs.html#gabbeb84002465867f52a05442e9c312fd", null ],
    [ "ble_tcs_evt_handler_t", "group__ble__sdk__srv__tcs.html#gabc4d02269d1c784f342edc872bdd29f9", null ],
    [ "ble_tcs_init", "group__ble__sdk__srv__tcs.html#gad33571ba0d7ba51659c3aa09618b3cc9", null ],
    [ "ble_tcs_mtu_set", "group__ble__sdk__srv__tcs.html#ga8a6b5889d593500659b05c563740c51a", null ],
    [ "ble_tcs_on_ble_evt", "group__ble__sdk__srv__tcs.html#ga10835bbd06a099abc38cdbee47c382f6", null ]
];