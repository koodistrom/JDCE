var group__drivers =
[
    [ "Accelerometer", "group__driver__acc.html", "group__driver__acc" ],
    [ "Color sensor", "group__color__driver.html", "group__color__driver" ],
    [ "GPIO extender", "group__gpio__ext__driver.html", "group__gpio__ext__driver" ],
    [ "Gas sensor", "group__gas__sensor.html", "group__gas__sensor" ],
    [ "Humidity sensor", "group__humidity__driver.html", "group__humidity__driver" ],
    [ "Microphone driver", "group__mic__driver.html", "group__mic__driver" ],
    [ "Motion sensor", "group__motion__driver.html", "group__motion__driver" ],
    [ "NFC driver", "group___n_f_c__driver.html", "group___n_f_c__driver" ],
    [ "Pressure sensor", "group__press__driver.html", "group__press__driver" ],
    [ "Speaker driver", "group__speaker__driver.html", "group__speaker__driver" ]
];