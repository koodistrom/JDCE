var structdrv__gas__init__t =
[
    [ "data_handler", "structdrv__gas__init__t.html#a99009da1f54e5be7ed4f1854876e8f12", null ],
    [ "p_twi_cfg", "structdrv__gas__init__t.html#a1c697dce8486b2fea3980ca9d6341b86", null ],
    [ "p_twi_instance", "structdrv__gas__init__t.html#ad56c3dcc9f5d68867bd6870d0341cbac", null ],
    [ "twi_addr", "structdrv__gas__init__t.html#a2f805e44817e12e87c8f3386e9acf50c", null ]
];