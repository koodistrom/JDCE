var group__m__motion =
[
    [ "Motion flash configuration", "group__m__motion__flash__config.html", "group__m__motion__flash__config" ],
    [ "m_motion_init_t", "structm__motion__init__t.html", null ],
    [ "MOTION_DEFAULT_CONFIG", "group__m__motion.html#ga719f39ce4cfd109fb686edef27527e8c", null ],
    [ "m_motion_init", "group__m__motion.html#ga12afedcc3b124fbb12e8be0418605f4f", null ],
    [ "m_motion_sleep_prepare", "group__m__motion.html#ga3f35031b629c996cea39ed68492ab747", null ]
];