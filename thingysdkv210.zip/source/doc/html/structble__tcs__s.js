var structble__tcs__s =
[
    [ "adv_param_handles", "structble__tcs__s.html#a3bc36c7a22700bb4e64b5ab49bea4a5c", null ],
    [ "conn_handle", "structble__tcs__s.html#aa0614613b1c7bc22a4e8c8f2eb92f9fa", null ],
    [ "conn_param_handles", "structble__tcs__s.html#a4ef5b98d85969326176dbe37ac1f5536", null ],
    [ "dev_name_handles", "structble__tcs__s.html#a3a063a210dd344b831584717989c8549", null ],
    [ "evt_handler", "structble__tcs__s.html#a4e21cc8c375065ede798c94934fa9aa3", null ],
    [ "service_handle", "structble__tcs__s.html#a7cdf0bc64e301eb2cbc8cd23f9239d54", null ],
    [ "uuid_type", "structble__tcs__s.html#a16efefe964dc754bb9aba36bb3656580", null ]
];