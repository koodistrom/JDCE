var structdrv__sx1509__cfg__t =
[
    [ "p_twi_cfg", "structdrv__sx1509__cfg__t.html#a3011e398a00ead6a1a8fb94507ee91eb", null ],
    [ "p_twi_instance", "structdrv__sx1509__cfg__t.html#a195ef7c845b316b2c31187a2af629b25", null ]
];