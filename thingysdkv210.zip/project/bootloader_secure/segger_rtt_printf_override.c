int SEGGER_RTT_printf(unsigned BufferIndex, const char * sFormat, ...)
{
    return 0;
}
